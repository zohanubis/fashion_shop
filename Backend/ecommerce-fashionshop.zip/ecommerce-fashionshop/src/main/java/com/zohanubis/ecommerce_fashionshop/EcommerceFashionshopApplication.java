package com.zohanubis.ecommerce_fashionshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceFashionshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceFashionshopApplication.class, args);
	}

}
