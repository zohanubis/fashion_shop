package com.zohanubis.ecommerce_fashionshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceFashionshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
